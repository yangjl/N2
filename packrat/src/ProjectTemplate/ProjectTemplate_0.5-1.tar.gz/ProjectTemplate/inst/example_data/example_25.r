example.25 <- data.frame(N = c(1, 2, 3, 4, 5), Prime = c(2, 3, 5, 7, 11))
